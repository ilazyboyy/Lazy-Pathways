package fr.lebon.lazypathways.blocks;

import java.util.Random;

import fr.lebon.lazypathways.LazyPathways;
import fr.lebon.lazypathways.entity.PathEntity;
import fr.lebon.lazypathways.util.GrowRoutineGrassBlock;
import net.minecraft.block.*;
import net.minecraft.block.entity.*;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2464;
import net.minecraft.class_2498;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_2758;
import net.minecraft.class_3218;
import net.minecraft.class_4538;
import net.minecraft.class_5558;
import com.mojang.serialization.MapCodec;
import org.jetbrains.annotations.Nullable;

public class PathBlock extends class_2237 implements class_2343, class_2256{
    
    public static final MapCodec<PathBlock> CODEC = method_54094(PathBlock::new);

    public static final class_2758 STATE_RENDER = class_2758.method_11867("state_render",1,5);
    public static final class_2746 STEPPED = class_2746.method_11825("stepped");
    
    

    /** setBlockState() flags that won't activate observers (and skips unnecessary lighting updates) */
    public static final int SKIP_ALL_NEIGHBOR_AND_LIGHTING_UPDATES = class_2248.field_31028 | class_2248.field_31031;

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> stateManager) {
        stateManager.method_11667(STEPPED);
        stateManager.method_11667(STATE_RENDER);
    }

    public PathBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9595().method_11664()
            .method_11657(STEPPED, false)
            .method_11657(STATE_RENDER, 1));
    }

    @Override
    protected MapCodec<? extends PathBlock> method_53969() {
        return field_46280;
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new PathEntity(pos, state);
    }

    @Override
    @Nullable
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return world.field_9236 ? null : method_31618(type, LazyPathways.PATH_ENTITY, PathEntity::tick);
    }

    @Override
    public void method_9591(class_1937 world, class_2338 pos,class_2680 state, class_1297 entity){
        if(!(world.method_8608()) && entity.method_5805()){
            if (!state.method_11654(STEPPED)) {
                world.method_8652(pos, state.method_11657(STEPPED, true), SKIP_ALL_NEIGHBOR_AND_LIGHTING_UPDATES);
            }
        }
    }

    @Override
    public boolean method_9651(class_4538 world, class_2338 pos, class_2680 state) {
        if(world.method_8320(pos).method_11654(STATE_RENDER) <= 3){ //if state ok so it can be fertilize
            return world.method_8320(pos.method_10084()).method_26215();
        }
        return false;
    }

    @Override
    public boolean method_9650(class_1937 world, net.minecraft.class_5819 random, class_2338 pos, class_2680 state) {
        return true;
    }

    @Override
    public void method_9652(class_3218 world, net.minecraft.class_5819 random, class_2338 pos, class_2680 state) {
        GrowRoutineGrassBlock.grow(world, random, pos, state, this);
    }
    
    @Override
    public class_2498 method_9573(class_2680 state) {
        // Get the path level (1-5)
        int pathLevel = state.method_11654(STATE_RENDER);
        
        // Gradually transition from grass to mud based on path level
        switch (pathLevel) {
            case 1: return class_2498.field_11535;           // Fresh path - still grassy
            case 2: return class_2498.field_28700;     // Slightly more solid
            case 3: return class_2498.field_37642;      // Getting compacted
            case 4: return class_2498.field_37640;             // Well-worn and muddy
            case 5: return class_2498.field_37640;             // Very worn, muddy
            default: return class_2498.field_11535;
        }
    }

}
