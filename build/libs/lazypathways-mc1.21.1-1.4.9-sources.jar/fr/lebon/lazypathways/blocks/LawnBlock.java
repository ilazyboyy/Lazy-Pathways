package fr.lebon.lazypathways.blocks;

import java.util.Random;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_4538;
import fr.lebon.lazypathways.util.GrowRoutineGrassBlock;

public class LawnBlock extends class_2248 implements class_2256 {

    public LawnBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    public boolean method_9651(class_4538 world, class_2338 pos, class_2680 state) {
        return true;
    }

    @Override
    public boolean method_9650(class_1937 world, net.minecraft.class_5819 random, class_2338 pos, class_2680 state) {
        return true;
    }

    @Override
    public void method_9652(class_3218 world, net.minecraft.class_5819 random, class_2338 pos, class_2680 state) {
        GrowRoutineGrassBlock.grow(world, random, pos, state, this);
    }
}
