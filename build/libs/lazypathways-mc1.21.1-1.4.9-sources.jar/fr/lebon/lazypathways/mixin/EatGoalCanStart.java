package fr.lebon.lazypathways.mixin;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import fr.lebon.lazypathways.LazyPathways;
import fr.lebon.lazypathways.blocks.PathBlock;
import net.minecraft.class_1308;
import net.minecraft.class_1345;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;


@Mixin(class_1345.class)
public class EatGoalCanStart {
    @Final
        @Mutable
        @Shadow
        private class_1308 mob;
    @Final
        @Mutable
        @Shadow
        private class_1937 world;
    @Final
        @Mutable
        @Shadow
        private int timer;

        @Inject(method = "canStart", cancellable = true, at = @At(value = "TAIL"))
    private void canStart(CallbackInfoReturnable<Boolean> cir) {

        class_2338 blockPosAutoPath = this.mob.method_24515();
        if(this.world.method_8320(blockPosAutoPath.method_10074()).method_27852(LazyPathways.LAWN_BLOCK)){
            cir.setReturnValue(true);
            cir.cancel();
        }
        if (this.world.method_8320(blockPosAutoPath.method_10074()).method_27852(LazyPathways.PATH_BLOCK)) {
            if(this.world.method_8320(blockPosAutoPath.method_10074()).method_11654(PathBlock.STATE_RENDER) > 3){
                cir.setReturnValue(false);
                cir.cancel();
            }
            cir.setReturnValue(true);
            cir.cancel();
        }
    }

    @Inject(method = "tick", cancellable = true, at = @At(value = "HEAD"))
    private void tick(CallbackInfo cir) {
        class_2338 blockPos = this.mob.method_24515();
        class_2338 blockPos2 = blockPos.method_10074();
        if (this.world.method_8320(blockPos2).method_27852(LazyPathways.LAWN_BLOCK)) {
            this.mob.method_5983();
            cir.cancel();
        }

        if (this.world.method_8320(blockPos2).method_27852(LazyPathways.PATH_BLOCK)) {
            if(this.world.method_8320(blockPos2).method_11654(PathBlock.STATE_RENDER) > 3){cir.cancel();}
            if (this.world.method_8450().method_8355(class_1928.field_19388)) {
                this.world.method_20290(2001, blockPos2, class_2248.method_9507(class_2246.field_10219.method_9564()));
                this.world.method_8652(blockPos2, class_2246.field_10566.method_9564(), 2);
            }
            this.mob.method_5983();
            cir.cancel();
        }
    }
}