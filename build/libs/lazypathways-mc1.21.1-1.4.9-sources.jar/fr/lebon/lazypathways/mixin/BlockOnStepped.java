package fr.lebon.lazypathways.mixin;

import fr.lebon.lazypathways.blocks.PathBlock;
import fr.lebon.lazypathways.config.LazyPathwaysConfig;
import me.shedaniel.autoconfig.AutoConfig;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.apache.logging.log4j.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import fr.lebon.lazypathways.LazyPathways;

@Mixin(class_2248.class)
public class BlockOnStepped {
        @Inject(method = "onSteppedOn", cancellable = true, at = @At(value = "HEAD"))
    private void transformGrassToPathWhenSteppedOn(class_1937 world, class_2338 pos, class_2680 state, class_1297 entity,CallbackInfo cir) {
        LazyPathwaysConfig config = AutoConfig.getConfigHolder(LazyPathwaysConfig.class).getConfig();
        boolean mob = config.enableMobPathCreation;
        //TODO Move those declaration, call at every creation of a path not efficient
        LazyPathways.log(Level.DEBUG,"" + mob);
        if(!mob && (entity instanceof class_1308)) cir.cancel();
        else if(state.method_27852(class_2246.field_10219) && (entity instanceof class_1309)){ //select grass and if entity is a mob or player
            world.method_8501(pos,LazyPathways.PATH_BLOCK.method_9564()); // We replace by a block path and notify other
            cir.cancel();
        }
    }
}