package fr.lebon.lazypathways.mixin;

import java.util.Iterator;

import net.minecraft.block.*;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2523;
import net.minecraft.class_2680;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_4538;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import fr.lebon.lazypathways.LazyPathways;
import fr.lebon.lazypathways.blocks.PathBlock;


@Mixin(class_2523.class) 
/**
 * Permet de placer les cannes a sucre sur les chemins du state 3 ou plus bas
 */
public class PathBlockSugarCane {
        @Inject(method = "canPlaceAt", at = @At("TAIL"), cancellable = true)
    private void test(class_2680 state, class_4538 world, class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        class_2680 blockState = world.method_8320(pos.method_10074());
        boolean trigger = false;

        if (blockState.method_27852(LazyPathways.PATH_BLOCK)) {
            if(blockState.method_11654(PathBlock.STATE_RENDER) <=3){//can't merge those 2 statement because we must be sure that the block is a Path block
                trigger = true;
            }
        }

        if(blockState.method_27852(LazyPathways.LAWN_BLOCK)){
            trigger = true;
        }

        if(trigger){
            class_2338 blockPos = pos.method_10074();
            Iterator var6 = class_2350.class_2353.field_11062.iterator();

            while (var6.hasNext()) {
                class_2350 direction = (class_2350) var6.next();
                class_2680 blockState2 = world.method_8320(blockPos.method_10093(direction));
                class_3610 fluidState = world.method_8316(blockPos.method_10093(direction));
                if (fluidState.method_15767(class_3486.field_15517) || blockState2.method_27852(class_2246.field_10110)) {
                   cir.setReturnValue(true);
               }
            }
        }
    }
}