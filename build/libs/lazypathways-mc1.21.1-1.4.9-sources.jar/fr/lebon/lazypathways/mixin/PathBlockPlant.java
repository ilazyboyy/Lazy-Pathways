package fr.lebon.lazypathways.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import fr.lebon.lazypathways.LazyPathways;
import fr.lebon.lazypathways.blocks.PathBlock;
import net.minecraft.class_1922;
import net.minecraft.class_2261;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

//Thanks to @SpaceWalker for the help on this !
@Mixin(class_2261.class)
/**
 * Permet de mettre de la grass, fleurs sur les chemins de state 3 ou plus bas
 */
public class PathBlockPlant {
        @Inject(method = "canPlantOnTop", cancellable = true, at = @At(value = "HEAD"))
    private void makePathPlantable(class_2680 floor, class_1922 world, class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        if (floor.method_27852(LazyPathways.PATH_BLOCK)) {
            if(floor.method_11654(PathBlock.STATE_RENDER) <=3){
                cir.setReturnValue(true);
                cir.cancel();
            }
            else{
                cir.setReturnValue(false);
                cir.cancel();
            }
            
        }

        if(floor.method_27852(LazyPathways.LAWN_BLOCK)){
            cir.setReturnValue(true);
            cir.cancel();
        }
    }
}