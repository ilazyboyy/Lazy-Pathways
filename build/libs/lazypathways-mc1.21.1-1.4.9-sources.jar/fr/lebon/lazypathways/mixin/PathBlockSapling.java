package fr.lebon.lazypathways.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import fr.lebon.lazypathways.LazyPathways;
import net.minecraft.class_2680;
import net.minecraft.class_3031;

@Mixin(class_3031.class) 
public class PathBlockSapling {
        @Inject(method = "isSoil(Lnet/minecraft/block/BlockState;)Z", cancellable = true, at = @At(value = "RETURN"))
    private static void makePathSaplingable(class_2680 state, CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValue() && (state.method_27852(LazyPathways.PATH_BLOCK) || state.method_27852(LazyPathways.LAWN_BLOCK))) cir.setReturnValue(true);
    }
}