package fr.lebon.lazypathways.mixin;


import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import fr.lebon.lazypathways.LazyPathways;
import net.minecraft.class_1269;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1794;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_3417;
import net.minecraft.class_3419;


@Mixin(class_1794.class) 

public class HoeMixin {
        @Inject(method = "useOnBlock", cancellable = true, at = @At("HEAD"))
    private void HoeModification(class_1838 context, CallbackInfoReturnable<class_1269> cir) {
        class_1937 world = context.method_8045();
        class_2338 pos = context.method_8037();

        if (context.method_8038() != class_2350.field_11033 && world.method_8320(pos.method_10084()).method_26215()) {
            boolean trigger = false;

            if (world.method_8320(pos).method_27852(LazyPathways.PATH_BLOCK) || world.method_8320(pos).method_27852(LazyPathways.LAWN_BLOCK)){
                trigger = true;
            }

            if(trigger){
                class_1657 playerEntity = context.method_8036();
                world.method_8396(playerEntity, pos, class_3417.field_14846, class_3419.field_15245, 1.0F, 1.0F);
                if (!world.field_9236) {
                    world.method_8652(pos, class_2246.field_10362.method_9564(), 11);
                    if (playerEntity != null) {
                        context.method_8041().method_7970(1, (class_1309)playerEntity, class_1304.field_6173);
                    }
                }
    
                cir.setReturnValue(class_1269.method_29236(world.field_9236));
                cir.cancel();
            }
        }
    }
}