package fr.lebon.lazypathways.entity;

import fr.lebon.lazypathways.LazyPathways;
import fr.lebon.lazypathways.config.LazyPathwaysConfig;
import fr.lebon.lazypathways.blocks.PathBlock;
import me.shedaniel.autoconfig.AutoConfig;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_7225;

public class PathEntity extends class_2586 {
    
    public int downgradeTime;
    public int upgradeTime;
    public boolean permanentActivate;
    public int steppedBeforePermanent;
    public boolean permanentAsDirtPath;

    public boolean permanent;
    public int timesWalkOn;
    public int nbTick; //Game will crash after 3years non stop of existing for the block 

    public PathEntity(class_2338 pos,class_2680 state) {
        super(LazyPathways.PATH_ENTITY, pos, state);
        
        LazyPathwaysConfig config = AutoConfig.getConfigHolder(LazyPathwaysConfig.class).getConfig();
        downgradeTime = config.downgradeTime*20;//Get time and convert from second to int
        upgradeTime = config.upgradeTime*20;
        permanentActivate = config.permanentPath;
        steppedBeforePermanent = config.steppedBeforePermanent;
        permanentAsDirtPath = config.permanentAsDirtPath;
        //TODO Move those declaration, call at every creation of a path not efficient
    }

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, PathEntity blockEntity){//20 ticks 1 seconde
        if (blockEntity.permanent) return; //Si permanent on ne fait plus rien
        if (world.method_8608()) return;

        // turn covered path to dirt
        class_2338 upPos = pos.method_10084();
        if (world.method_8320(upPos).method_26212(world, upPos)) { // si le block au dessus est solide
            world.method_8501(pos, class_2246.field_10566.method_9564());
            return;
        }

        boolean stepped = state.method_11654(PathBlock.STEPPED);
        int renderState = state.method_11654(PathBlock.STATE_RENDER);

        if (stepped && blockEntity.nbTick >= blockEntity.upgradeTime) { // default 2400

            // upgrade render state if possible
            if (renderState + 1 <= 5) {
                state = state.method_11657(PathBlock.STATE_RENDER, renderState + 1);
                blockEntity.nbTick = 0;
            // try turning path to permanent path
            } else if (renderState == 5) {
                if (blockEntity.permanentActivate) {
                    if (blockEntity.timesWalkOn == blockEntity.steppedBeforePermanent) {
                        if (blockEntity.permanentAsDirtPath) {
                            world.method_8501(pos, class_2246.field_10194.method_9564());
                            return;
                        }
                        else{
                            blockEntity.permanent = true;
                        }
                    }
                }
                blockEntity.timesWalkOn++;
                blockEntity.nbTick = 0;
            }

        } else if (blockEntity.nbTick >= blockEntity.downgradeTime) { // default 7200

            if (renderState - 1 <= 0) {
                // downgrade back to grass
                world.method_8501(pos, class_2246.field_10219.method_9564());
                return; // Le block est detruit
            }

            // downgrade render state
            state = state.method_11657(PathBlock.STATE_RENDER, renderState - 1);
            blockEntity.timesWalkOn = 0;
            blockEntity.nbTick = 0;
        }

        world.method_8652(pos, state.method_11657(PathBlock.STEPPED, false), PathBlock.SKIP_ALL_NEIGHBOR_AND_LIGHTING_UPDATES); // We use our custom flag  because we dont need to notify neigbours
        blockEntity.nbTick++;
    }

    @Override
    public void method_11007(class_2487 tag, class_7225.class_7874 wrapperLookup) {
        super.method_11007(tag, wrapperLookup);
        tag.method_10569("nbTick", nbTick);
        tag.method_10556("permanent", permanent);
        tag.method_10569("timesWalkOn", timesWalkOn);

    }

    @Override
    public void method_11014(class_2487 tag, class_7225.class_7874 wrapperLookup) {
        super.method_11014(tag, wrapperLookup);
        nbTick = tag.method_10550("nbTick");
        permanent = tag.method_10577("permanent");
        timesWalkOn = tag.method_10550("timesWalkOn");
    }

}
