package fr.lebon.lazypathways;


import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_7706;
import net.minecraft.class_7923;
import net.minecraft.item.*;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import fr.lebon.lazypathways.blocks.LawnBlock;
import fr.lebon.lazypathways.blocks.PathBlock;
import fr.lebon.lazypathways.config.LazyPathwaysConfig;
import fr.lebon.lazypathways.entity.PathEntity;
import me.shedaniel.autoconfig.AutoConfig;
import me.shedaniel.autoconfig.serializer.GsonConfigSerializer;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;

public class LazyPathways implements ModInitializer{

        public static Logger LOGGER = LogManager.getLogger();

        public static final String MOD_ID = "lazypathways";
        public static final String MOD_NAME = "Lazy Pathways";

    public static final class_2248 PATH_BLOCK = new PathBlock(FabricBlockSettings.method_9637().method_31710(class_3620.field_16000).method_50012(class_3619.field_15971).method_36557(0.5f).method_9626(class_2498.field_11535));
        public static final class_2248 LAWN_BLOCK = new LawnBlock(FabricBlockSettings.method_9637().method_31710(class_3620.field_16000).method_50012(class_3619.field_15971).method_36557(0.5f).method_9626(class_2498.field_11535));

        public static final class_1747 LAWN_ITEM = new class_1747(LAWN_BLOCK, new class_1792.class_1793());
        public static final class_1747 PATH_ITEM = new class_1747(PATH_BLOCK, new class_1792.class_1793());

        public static class_2591<PathEntity> PATH_ENTITY;

    @Override
    public void onInitialize() {
        log(Level.INFO, "Initializing");

        log(Level.INFO, "Register Blocks");

        class_2378.method_10230(class_7923.field_41175, class_2960.method_60655("lazypathways", "path"), PATH_BLOCK);
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40743).register(entries -> entries.method_45421(PATH_ITEM));
        class_2378.method_10230(class_7923.field_41178, class_2960.method_60655("lazypathways", "path"), PATH_ITEM);

        class_2378.method_10230(class_7923.field_41175, class_2960.method_60655("lazypathways", "lawn"), LAWN_BLOCK);
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40743).register(entries -> entries.method_45421(LAWN_ITEM));
        class_2378.method_10230(class_7923.field_41178, class_2960.method_60655("lazypathways", "lawn"), LAWN_ITEM);

        PATH_ENTITY = class_2378.method_10226(class_7923.field_41181, "lazypathways:path", FabricBlockEntityTypeBuilder.create(PathEntity::new, PATH_BLOCK).build());

        log(Level.INFO, "Initializing config");
        AutoConfig.register(LazyPathwaysConfig.class, GsonConfigSerializer::new);
    }

    public static void log(Level level, String message){
        LOGGER.log(level, "["+MOD_NAME+"] " + message);
    }


}