package fr.lebon.lazypathways.util;

import java.util.List;
import java.util.Optional;

import net.minecraft.block.*;
import net.minecraft.class_1959;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2256;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2975;
import net.minecraft.class_3218;
import net.minecraft.class_4638;
import net.minecraft.class_5819;
import net.minecraft.class_6796;
import net.minecraft.class_6819;
import net.minecraft.class_6880;
import net.minecraft.class_7924;


public class GrowRoutineGrassBlock {

    private GrowRoutineGrassBlock(){//Util class
}

    public static void grow(class_3218 world, class_5819 random, class_2338 pos, class_2680 state,class_2248 callerBlock) {
        class_2338 blockPos = pos.method_10084();
        class_2680 blockState = class_2246.field_10479.method_9564();
        Optional<class_6880.class_6883<class_6796>> optional = world.method_30349().method_30530(class_7924.field_41245).method_40264(class_6819.field_36173);

        label48:
        for(int i = 0; i < 128; ++i) {
            class_2338 blockPos2 = blockPos;

            for(int j = 0; j < i / 16; ++j) {
                blockPos2 = blockPos2.method_10069(random.method_43048(3) - 1, (random.method_43048(3) - 1) * random.method_43048(3) / 2, random.method_43048(3) - 1);
                if (!world.method_8320(blockPos2.method_10074()).method_27852(callerBlock) || world.method_8320(blockPos2).method_26234(world, blockPos2)) {
                continue label48;
                }
            }

            class_2680 blockState2 = world.method_8320(blockPos2);
            if (blockState2.method_27852(blockState.method_26204()) && random.method_43048(10) == 0) {
                ((class_2256)blockState.method_26204()).method_9652(world, random, blockPos2, blockState2);
            }

            if (blockState2.method_26215()) {
                                class_6880 registryEntry;
                                if (random.method_43048(8) == 0) {
                                        List<class_2975<?, ?>> list = ((class_1959)world.method_23753(blockPos2).comp_349()).method_30970().method_30982();
                                        if (list.isEmpty()) {
                                                continue;
                                        }

                                        registryEntry = ((class_4638)((class_2975)list.get(0)).comp_333()).comp_155();
                                } else {
                                        if (!optional.isPresent()) {
                                                continue;
                                        }

                                        registryEntry = (class_6880)optional.get();
                                }

                                ((class_6796)registryEntry.comp_349()).method_39644(world, world.method_14178().method_12129(), random, blockPos2);
                        }
        }
    }
}
