package fr.lebon.lazypathways.util;

import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class ColorProvider {
    
    public static int getPathColor(class_2680 state, class_1920 view, class_2338 pos, int tintIndex){
        // Return a static color - no dynamic color changes based on biome or wear level
        return 0xFFFFFF; // White - lets the texture show its natural colors
    }
    
    public static int getLawnColor(class_2680 state, class_1920 view, class_2338 pos, int tintIndex){
        // Return a static color - no dynamic color changes based on biome
        return 0xFFFFFF; // White - lets the texture show its natural colors
    }
}
