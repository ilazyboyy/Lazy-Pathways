package fr.lebon.lazypathways.util;

import net.minecraft.class_1163;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class ColorProvider {
    
    public static int getPathColor(class_2680 state, class_1920 view, class_2338 pos, int tintIndex){
        if (view == null || pos == null) {
            return 0x7CB342; // Default grass green as fallback
        }
        
        // Use the biome's grass color but don't do complex blending or level-based changes
        return class_1163.method_4962(view, pos);
    }
    
    public static int getLawnColor(class_2680 state, class_1920 view, class_2338 pos, int tintIndex){
        if (view == null || pos == null) {
            return 0x7CB342; // Default grass green as fallback
        }
        
        // Use the biome's grass color for lawn blocks
        return class_1163.method_4962(view, pos);
    }
}
